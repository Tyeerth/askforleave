package com.leave.service;

public class Leave_userService {
	/*public void excelToOut() {
		Leave_userDao lUserDao = new Leave_userDao();
		ArrayList<Leave_user> arrayList = lUserDao.selectExcel();
		Excel excel = new Excel();
		excel.excelOut(arrayList);
	}
	public static void main(String[] args) {
		Leave_userService leave_userService = new Leave_userService();
		leave_userService.excelTout();
	}*/
}
