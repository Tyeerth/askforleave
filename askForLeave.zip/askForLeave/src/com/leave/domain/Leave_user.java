package com.leave.domain;
/**
 * 本代码暂未使用
 * @author lu
 *
 */
public class Leave_user {
	private Integer id;
	private String user_name;
	private String user_sex;
	private String user_born_time;
	private String user_work_time;
	private String user_origin;
	private String user_spouse_origin;
	private String user_work_address;
	private String user_position;
	private String user_position_rank;
	private String user_class_area;
	private String user_separated;
	private Integer user_phone;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public void User_born_time(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_born_time() {
		return user_born_time;
	}
	public void setUser_born_time(String user_born_time) {
		this.user_born_time = user_born_time;
	}
	public String getUser_work_time() {
		return user_work_time;
	}
	public void setUser_work_time(String user_work_time) {
		this.user_work_time = user_work_time;
	}
	public String getUser_origin() {
		return user_origin;
	}
	public void setUser_origin(String user_origin) {
		this.user_origin = user_origin;
	}
	public String getUser_spouse_origin() {
		return user_spouse_origin;
	}
	public void setUser_spouse_origin(String user_spouse_origin) {
		this.user_spouse_origin = user_spouse_origin;
	}
	public String getUser_work_address() {
		return user_work_address;
	}
	public void setUser_work_address(String user_work_address) {
		this.user_work_address = user_work_address;
	}
	public String getUser_position() {
		return user_position;
	}
	public void setUser_position(String user_position) {
		this.user_position = user_position;
	}
	public String getUser_position_rank() {
		return user_position_rank;
	}
	public void setUser_position_rank(String user_position_rank) {
		this.user_position_rank = user_position_rank;
	}
	public String getUser_class_area() {
		return user_class_area;
	}
	public void setUser_class_area(String user_class_area) {
		this.user_class_area = user_class_area;
	}
	public String getUser_separated() {
		return user_separated;
	}
	public void setUser_separated(String user_separated) {
		this.user_separated = user_separated;
	}
	public Integer getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(Integer user_phone) {
		this.user_phone = user_phone;
	}
	
}
